# Case-study videos

The Huugo launch film and Accessible Trades product-video example each appear
in **Delivery and outcomes** in their respective case studies. The homepage
links directly to the Accessible Trades video at
`/work/accessible-trades#ai-video-workflow`.
The update deliberately includes no MP4. Missing media does not prevent a build.

## Add and optimise the original

1. Install FFmpeg on your computer (macOS: `brew install ffmpeg`).
2. Save each original in `src/assets/videos/original/` using the filename below.
3. Run `node scripts/optimise-videos.mjs` from the project root.
4. Review the generated MP4 in `public/videos/`, then build and deploy normally.

| Case study        | Original filename                | Generated public URL                     |
| ----------------- | -------------------------------- | ---------------------------------------- |
| Huugo             | `huugo-promotion.mp4`            | `/videos/huugo-promotion.mp4`            |
| Accessible Trades | `accessible-trades-workflow.mp4` | `/videos/accessible-trades-workflow.mp4` |

The script processes all MP4s in the originals folder. For Accessible Trades,
add `src/assets/videos/original/accessible-trades-workflow.mp4` and run the same
command. There is no need to change or duplicate the optimiser.

Only the optimised file in `public/videos/` is deployed. The original stays in
`src/assets/videos/original/` and is not imported into the app. Do not store the
original in `public/`. The command is optional and separate from the existing
Sharp image optimiser, so Netlify does not need FFmpeg to build the site. Commit
or otherwise supply the generated public MP4 before deploying. No new npm
dependency or package-lock change is required.

You may instead copy an already optimised MP4 directly to
`public/videos/huugo-promotion.mp4`. For a separately hosted file, change `src`
in `src/data/projectVideos.ts` to its HTTPS URL.

## Compression choices

The script encodes H.264 video with AAC audio, CRF 25, a slow encoding preset,
YUV420p output, a maximum dimension of 1280 pixels and MP4 fast-start metadata.
It retains aspect ratio, avoids enlargement and accepts videos without audio.
Lower CRF retains more detail with larger files; higher CRF usually compresses
further. Try `node scripts/optimise-videos.mjs 23` if interface text loses clarity,
or `node scripts/optimise-videos.mjs 28` for a smaller version to compare.

It prints original/output sizes and never overwrites the original. A failed
encode leaves the previous public MP4 intact. Output may be larger if the
source is already efficient; always compare the result. Avoid repeatedly
encoding an already compressed output. Use the original as input each time.
Compression savings depend on source duration, codec, motion and resolution;
there is no guaranteed target size for the supplied 11 MB file without encoding it.

For example, a 4 MB result watched in full 1,000 times is approximately 4 GB of
video transfer, excluding other assets and repeat requests. Compression reduces
bytes per playback; it does not remove hosting bandwidth usage. For substantially
more traffic, a separate video host can keep those bytes off the portfolio host.

## Playback and accessibility

The initial page contains a lightweight poster and a real Play button. The MP4
is not attached to a media element until the visitor activates that button.
The native player uses controls, inline playback and `preload="none"`, with no
autoplay or looping. Navigating away stops playback. A direct MP4 link remains
available, including without JavaScript; missing/unsupported media has an error
message. The posters use existing case-study artwork, not frames extracted from the films.

Configure title, caption, explanatory paragraphs, play-button label, poster, dimensions and source in
`src/data/projectVideos.ts`. Set width/height to the actual video aspect ratio if
different from 16:9. Set `captionsSrc: "/videos/huugo-promotion.en.vtt"` after adding
a checked WebVTT file to `public/videos/`. Captions should include speech and
meaningful sound. Add `transcript: ["..."]` with the actual checked transcript,
including important on-screen information, to expose the transcript disclosure.
Use `/videos/accessible-trades-workflow.en.vtt` for the Accessible Trades captions.
No captions or transcript are fabricated by this patch. Add them before publishing
if needed to make the film's information accessible. The case-study reading
estimate counts configured text, not the film's playback duration.

## Check before publishing

- Inspect fine text, character details and audio after compression.
- In DevTools Network, confirm no MP4 request occurs before Play.
- Test keyboard Play, native controls, captions and opening the direct MP4 link.
- Test mobile inline/fullscreen playback, navigating away and missing-file behaviour.
- Verify the public MP4 URL serves video/mp4, not the SPA fallback HTML.

References: https://ffmpeg.org/ffmpeg-codecs.html,
https://ffmpeg.org/ffmpeg-formats.html,
https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/video
