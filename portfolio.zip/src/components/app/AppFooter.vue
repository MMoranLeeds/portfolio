<script setup lang="ts">
import { profile, emailHref } from "@/config/profile";
import ActionLink from "@/components/ui/ActionLink.vue";
</script>
<template>
  <footer
    id="contact"
    class="contact-section"
    aria-labelledby="contact-heading"
    tabindex="-1"
  >
    <div class="chapter-number" aria-hidden="true">08<span /></div>
    <h2 id="contact-heading">Contact</h2>
    <p>
      If you’d like to discuss an opportunity or hear more about how I approach
      research, design and delivery, I’d be happy to talk.
    </p>
    <div class="contact-actions">
      <ActionLink :href="emailHref" class="contact-email" external>
        <span class="contact-email-label"
          >Email me at {{ profile.email }}</span
        > </ActionLink
      ><ActionLink :href="profile.phoneHref"
        >Call me on {{ profile.phone }}</ActionLink
      ><ActionLink :href="profile.linkedin" external
        >Connect with me on LinkedIn</ActionLink
      ><ActionLink :href="profile.cvUrl">View my CV</ActionLink>
    </div>
    <p class="footer-note">
      © {{ new Date().getFullYear() }} {{ profile.name }}
    </p>
  </footer>
</template>

<style scoped>
.contact-email {
  max-width: 100%;
}
.contact-email-label {
  min-width: 0;
  overflow-wrap: anywhere;
}
</style>
