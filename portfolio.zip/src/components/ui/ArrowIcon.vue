<template>
  <svg class="arrow-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path
      d="M4 12h15m-6-6 6 6-6 6"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
