export interface CaseStudyOverview {
  outcome: string;
  period: string;
  launchDate?: string;
  launchLabel?: string;
}

// Recruiter-facing summaries and project periods, shared by the view and read time.
export const caseStudyOverviews: Record<string, CaseStudyOverview> = {
  "fruugo-localisation": {
    outcome:
      "Turned multilingual research into typography and language-control improvements across Fruugo’s shopper and merchant products. The Marketplace language picker and Merchant Portal font update are now live, with further changes awaiting deployment.",
    period: "Q3 2026 · Ongoing rollout",
  },
  "fruugo-merchant-onboarding": {
    outcome:
      "Simplified the merchant application by moving integration questions to a more appropriate stage and improving guidance throughout the journey. An early survey of 24 respondents returned a 4.5/5 rating for ease of completion.",
    period: "Q4 2025",
  },
  "huugo-from-fruugo": {
    outcome:
      "Took the CTO’s proof of concept into a launched AI shopping experience, leading UX and implementing most of the frontend. The production page achieved a Lighthouse performance score of 99/100, while early gross transaction value reached 18.4 times the associated AI-model spend.",
    period: "Q3 2026",
    launchDate: "2026-10-08",
    launchLabel: "8 October 2026",
  },
  "accessible-trades": {
    outcome:
      "Created and launched an independent service with 240 evidence-supported company listings and council coverage across England. The MND Association has begun using and sharing the service internally.",
    period: "Personal project · Q2 2026 development · Ongoing development",
    launchDate: "2026-07-19",
    launchLabel: "19 July 2026",
  },
};
