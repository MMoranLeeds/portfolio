import metadata from "@/assets/images/dist/metadata.json";
import localisation from "@/assets/images/mobile-placeholders/fruugo-localisation.svg";
import onboarding from "@/assets/images/mobile-placeholders/fruugo-merchant-onboarding.svg";
import huugo from "@/assets/images/mobile-placeholders/huugo-from-fruugo.svg";
import accessibleTrades from "@/assets/images/mobile-placeholders/accessible-trades.svg";
import type { ProjectImage } from "@/types/project";

const placeholders: Record<string, { src: string; title: string }> = {
  "fruugo-localisation": { src: localisation, title: "Localisation at Fruugo" },
  "fruugo-merchant-onboarding": {
    src: onboarding,
    title: "Merchant onboarding",
  },
  "huugo-from-fruugo": { src: huugo, title: "Huugo from Fruugo" },
  "accessible-trades": { src: accessibleTrades, title: "Accessible Trades" },
};
const files = import.meta.glob<string>(
  "/src/assets/images/dist/mobile/*.webp",
  { eager: true, query: "?url", import: "default" },
);
const dimensions: Record<string, { width: number; height: number }> = metadata;
// Generated portraits are artwork, distinct from the supplied mobile screenshots.
const descriptions: Record<
  string,
  { label: string; alt: string; caption: string }
> = {
  "accessible-trades": {
    label: "Mobile homepage",
    alt: "Accessible Trades mobile homepage showing location search, search distance and a Next button.",
    caption: "Location search and distance selection on the mobile homepage.",
  },
  "fruugo-merchant-onboarding": {
    label: "Mobile application entry",
    alt: "Fruugo mobile onboarding page with Start application and Resume application choices.",
    caption:
      "The mobile entry point offers clear routes to start or resume an application.",
  },
  "huugo-from-fruugo": {
    label: "Portrait identity illustration",
    alt: "Portrait artwork of Huugo’s blue character with shopping and search speech bubbles.",
    caption:
      "Huugo identity artwork, presented in portrait format rather than as an interface screenshot.",
  },
  "fruugo-localisation": {
    label: "Portrait localisation illustration",
    alt: "Portrait artwork with Latin, Chinese, Korean and Cyrillic characters on blue and white speech-bubble tiles.",
    caption:
      "Multilingual typography illustrated in portrait format; this is not an interface screenshot.",
  },
};
export interface MobilePreview extends ProjectImage {
  placeholder: boolean;
}

/** Add original/mobile/<project-slug>.png and optimise to replace automatically. */
export function projectMobilePreview(slug: string): MobilePreview | undefined {
  const fallback = placeholders[slug];
  if (!fallback) return;
  const stem = `mobile/${slug}`;
  const variants = ["-320", "-640", "-960", ""].flatMap((suffix) => {
    const name = `${stem}${suffix}.webp`;
    const src = files[`/src/assets/images/dist/${name}`];
    const size = dimensions[name];
    return src && size ? [{ src, ...size }] : [];
  });
  if (variants.length) {
    const full = variants.at(-1)!;
    const display = variants[1] || full;
    const unique = variants.filter(
      (image, index) =>
        variants.findIndex((other) => other.width === image.width) === index,
    );
    return {
      ...display,
      fullSrc: full.src,
      srcset: unique.map((image) => `${image.src} ${image.width}w`).join(", "),
      sizes: "(max-width: 639px) 17vw, 126px",
      label: descriptions[slug]?.label || "Mobile view",
      alt:
        descriptions[slug]?.alt ||
        `${fallback.title} interface on a mobile viewport.`,
      caption:
        descriptions[slug]?.caption ||
        `Mobile interface for ${fallback.title}.`,
      placeholder: false,
    };
  }
  return {
    src: fallback.src,
    width: 390,
    height: 844,
    label: "Mobile preview · placeholder",
    alt: `Placeholder for a mobile screenshot of ${fallback.title}.`,
    caption: "Mobile screenshot to follow.",
    placeholder: true,
  };
}
