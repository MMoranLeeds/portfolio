import { projectCover } from "./projectCovers";

export interface ProjectVideo {
  id?: string;
  sectionId: string;
  title: string;
  src: string;
  poster: string;
  caption: string;
  paragraphs?: string[];
  playLabel?: string;
  width: number;
  height: number;
  captionsSrc?: string;
  transcript?: string[];
}

// Public video URLs may also point to a separately hosted MP4.
// Add captionsSrc and a checked transcript once those files/text are available.
export const projectVideos: Record<string, ProjectVideo> = {
  "huugo-from-fruugo": {
    sectionId: "delivery",
    title: "Introducing Huugo",
    playLabel: "Watch launch film",
    src: "/videos/huugo-promotion.mp4",
    poster: projectCover("huugo-shopping-journey").src,
    caption:
      "The promotional film used to announce the launch of Huugo, Fruugo’s AI shopping assistant.",
    width: 1280,
    height: 720,
  },
  "accessible-trades": {
    id: "ai-video-workflow",
    sectionId: "delivery",
    title: "Streamlining product video production",
    src: "/videos/accessible-trades-workflow.mp4",
    poster: projectCover("accessible-trades-journey").src,
    caption:
      "An Accessible Trades product video, produced using AI and Recordly.",
    paragraphs: [
      "I combined AI-assisted video production with screen recordings made in Recordly to create a repeatable workflow for product videos. The aim was to reduce the time and resources needed to turn a working interface into a clear product demonstration.",
      "I used this workflow to produce the Accessible Trades video independently, bringing together work that would typically involve several contributors within a short production cycle.",
    ],
    playLabel: "Watch product video",
    width: 1280,
    height: 720,
  },
};
