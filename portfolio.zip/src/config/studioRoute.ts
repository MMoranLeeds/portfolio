export const shareStudioPath = "/_studio/share-image";
// Hosted access is opt-in and requires the Netlify server-side guard.
export const shareStudioEnabled =
  import.meta.env.DEV || import.meta.env.VITE_ENABLE_SHARE_STUDIO === "true";
