export interface SocialPreview {
  path: string;
  width: number;
  height: number;
  type: "image/png" | "image/jpeg";
  alt: string;
}

// Public URLs, not source imports. Replace files here with studio downloads.
export const socialPreview: SocialPreview = {
  path: "/images/portfolio-social-preview.png",
  width: 1200,
  height: 630,
  type: "image/png",
  alt: "Matthew Moran, Lead Product Designer portfolio.",
};

export const pageSocialPreviews: Record<string, SocialPreview> = {
  "/work/fruugo-localisation": {
    path: "/images/social/fruugo-localisation.png",
    width: 1200,
    height: 630,
    type: "image/png",
    alt: "Localisation at Fruugo case study by Matthew Moran, with multilingual character artwork.",
  },
  "/work/fruugo-merchant-onboarding": {
    path: "/images/social/fruugo-merchant-onboarding.png",
    width: 1200,
    height: 630,
    type: "image/png",
    alt: "Merchant onboarding at Fruugo case study by Matthew Moran, with the merchant interface.",
  },
  "/work/huugo-from-fruugo": {
    path: "/images/social/huugo-from-fruugo.png",
    width: 1200,
    height: 630,
    type: "image/png",
    alt: "Huugo from Fruugo case study by Matthew Moran, featuring the AI shopping assistant.",
  },
  "/work/accessible-trades": {
    path: "/images/social/accessible-trades.png",
    width: 1200,
    height: 630,
    type: "image/png",
    alt: "Accessible Trades case study by Matthew Moran, with the home adaptation service.",
  },
};

// Add any route, including /cv, to the map above. Other pages use the portfolio image.
export function socialPreviewFor(path: string): SocialPreview {
  return pageSocialPreviews[path.replace(/\/+$/, "") || "/"] || socialPreview;
}
