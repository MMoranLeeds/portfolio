import assert from "node:assert/strict";
import { readFile, readdir, access } from "node:fs/promises";
import guard, { config } from "../netlify/edge-functions/share-studio-auth.js";
const settings = new Map();
globalThis.Netlify = { env: { get: (key) => settings.get(key) } };
let nextCalls = 0;
const context = {
  next: async () => {
    nextCalls++;
    return new Response("Studio content");
  },
};
const request = (auth) =>
  new Request("https://example.test/_studio/share-image", {
    headers: auth ? { Authorization: auth } : {},
  });
assert.equal((await guard(request(), context)).status, 503);
settings.set("SHARE_STUDIO_USER", "owner");
settings.set("SHARE_STUDIO_PASSWORD", "test-only-long-password-123");
for (const auth of [
  undefined,
  "Basic ???",
  "Bearer wrong",
  `Basic ${btoa("owner:incorrect")}`,
]) {
  const response = await guard(request(auth), context);
  assert.equal(response.status, 401);
  assert(response.headers.get("www-authenticate").includes("Basic"));
  assert.equal(response.headers.get("cache-control"), "no-store");
}
assert.equal(
  nextCalls,
  0,
  "Unauthorised requests must not reach the HTML or assets",
);
const allowed = await guard(
  request(`Basic ${btoa("owner:test-only-long-password-123")}`),
  context,
);
assert.equal(allowed.status, 200);
assert.equal(await allowed.text(), "Studio content");
assert.equal(
  allowed.headers.get("x-robots-tag"),
  "noindex, nofollow, noarchive",
);
assert.equal(allowed.headers.get("cache-control"), "no-store");
assert.equal(
  (
    await guard(request(`Basic ${btoa("owner:test-only-long-password-123")}`), {
      next: async () => {
        throw new Error("Failure");
      },
    })
  ).status,
  503,
);
assert(config.path.includes("/_studio/share-image/*"));
assert(config.path.includes("/assets/ShareImageStudio*"));
delete globalThis.Netlify;
const enabled = process.argv.includes("--enabled");
const files = await readdir("dist/assets");
const studio = files.filter((file) => file.startsWith("ShareImageStudio"));
const sitemap = await readFile("dist/sitemap.xml", "utf8");
assert(!sitemap.includes("_studio"));
const homepage = await readFile("dist/index.html", "utf8");
assert(!homepage.includes('href="/_studio/share-image'));
assert(
  !/<(?:script|link)[^>]*(?:src|href)="[^"]*ShareImageStudio/.test(homepage),
  "Public page must not load/preload studio code",
);
if (enabled) {
  assert(studio.some((file) => file.endsWith(".js")));
  await access("dist/_studio/share-image/index.html");
  const html = await readFile("dist/_studio/share-image/index.html", "utf8");
  assert(html.includes('content="noindex, nofollow, noarchive"'));
  assert(!html.includes("application/ld+json"));
  assert(html.includes("Share image studio"));
  for (const name of ["Download PNG", "Download JPEG"])
    assert(html.includes(name));
  for (const file of files.filter(
    (file) => file.startsWith("index-") && file.endsWith(".js"),
  )) {
    const js = await readFile(`dist/assets/${file}`, "utf8");
    assert(
      !js.includes("Horizontal crop"),
      "Studio UI must remain in its own lazy chunk",
    );
  }
} else {
  assert.equal(
    studio.length,
    0,
    "Default production builds must omit studio chunks",
  );
}
console.log(
  "Authentication rejects unauthorised requests and failures; private HTML/assets, metadata, sitemap and lazy loading verified.",
);
