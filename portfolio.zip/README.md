# Matthew Moran portfolio

Vue 3 and TypeScript portfolio with an editorial sidebar, responsive selected-work cards and reusable case-study pages. Vue Router handles browser navigation; the production build renders every configured project into static HTML.

## Apply this update

The merchant-onboarding ZIP is an incremental patch for the current project uploaded as `portfolio(2).zip`. It contains only this update’s additions and replacements, not a complete application or cumulative replacement. Back up your current project, then copy its contents into the project root, preserving the folder paths and replacing the matching files. Retain all other existing files, including your portrait and button styles. See `UPDATE_NOTES.md` for the change summary.

Use Node 24.12 or newer, or Node 22.18 or newer within the Node 22 series.

```bash
npm ci
npm run dev
```

No API keys or backend are needed. The updated lockfile includes Vue Router.

## Production domain and build

Copy `.env.example` to `.env.production` and replace its value with your actual portfolio origin:

```text
VITE_SITE_URL=https://your-actual-portfolio-domain
```

Use the portfolio domain, not Accessible Trades' domain. Include the protocol; omit any path, query or hash. Root-domain hosting is configured. Subdirectory hosting would need coordinated changes to Vite base, router history, public asset URLs and canonical generation.

```bash
npm run build
npm run test:static
npm run preview
```

The build runs image optimisation, strict TypeScript checks, Vite's client build, a temporary server build and static rendering. It produces:

- `dist/index.html`, the portfolio with complete readable content.
- `dist/work/accessible-trades/index.html`, the Accessible Trades case study.
- `dist/work/huugo-from-fruugo/index.html`, the Huugo case study.
- `dist/work/fruugo-localisation/index.html`, the localisation case study.
- `dist/work/fruugo-merchant-onboarding/index.html`, the merchant-onboarding case study.
- One `dist/work/<slug>/index.html` per additional project in the data file.
- `dist/404.html`, a useful page with `noindex` metadata.
- `dist/sitemap.xml` and `dist/robots.txt`.
- Hashed JavaScript, CSS and portrait assets, plus the public project illustrations.

The temporary `.ssr/` directory is removed after successful rendering. Deploy **only `dist/`**. No Node server is needed in production. The browser hydrates the static markup, then handles subsequent navigation with Vue Router.

Without a configured public origin, the build still works for local testing, but intentionally uses `noindex` and disallows crawling. **Set the real origin and rebuild before publishing or running a production SEO audit.** Changing an environment variable after deployment cannot rewrite already generated HTML.

## Hosting and direct links

Your static host must serve `/work/accessible-trades/index.html` when someone visits `/work/accessible-trades` or its trailing-slash equivalent. Preserve real files and return `404.html` with HTTP status 404 for unknown paths. Avoid rewriting every unknown URL to the homepage with status 200, which creates soft 404s.

`public/_redirects` provides the missing-page fallback for Netlify. Other hosts require their own configuration. For Nginx, a typical root-domain setup is:

```nginx
location / {
  try_files $uri $uri/index.html =404;
}
error_page 404 /404.html;
location = /404.html {
  internal;
}
```

Vite's development and preview servers are for local work and may apply a SPA fallback to unknown URLs. Check HTTP status handling on the actual host.

## Edit content and add projects

- `src/data/portfolio.ts`: homepage copy and section navigation.
- `src/data/projects.ts`: the shared project registry, including Accessible Trades.
- `src/data/huugoProject.ts`: Huugo content, market context and public source references.
- `src/data/localisationProject.ts`: localisation research, audit methodology, programme decisions and rollout context.
- `src/types/project.ts`: shared project content contract.
- `src/views/CaseStudyView.vue`: the single reusable template for every project.
- `src/config/profile.ts`: contact details, CV and project link.
- `src/config/site.ts`: public origin and indexing behaviour.
- `src/seo/metadata.ts`: shared static and browser metadata generation.

Add an object to `projects` with a unique lower-case, hyphen-separated `slug`, title, category, summary, role, status, skills, external URL, SEO description, cover image and sections. Rebuild. The card, route content, static page and sitemap are generated automatically. Do not create a new Vue page for each project.

Projects may provide custom source context and external link labels. Source entries without a public URL render as text, allowing internal evidence to be attributed without exposing private tracking links.

Each section has an ID, heading and paragraphs, with an optional image, eyebrow, decision points, ordered workflow steps, research highlights and source references. Projects can include a public sources list. All are rendered by the same template. Images specify `src`, `alt`, `caption`, `width` and `height`. Use actual image dimensions, useful alternative text and captions that explain the decision or finding. Keep section IDs unique within each project.

Accessible Trades, Huugo from Fruugo and Localisation at Fruugo are included. Huugo is now a selected-work card and a dedicated case study, replacing the long homepage example under “AI & modern workflows”. Its content covers Matt’s UX research/design, front-end implementation, character identity and reusable creative workflow. Delivered contributions, public market evidence and proposed agentic capabilities are distinct. No research sample sizes or conversion results have been invented.

## Huugo evidence and publication review

Huugo’s market section uses linked primary reports from Google/Ipsos and McKinsey. Survey findings have their cohort and limitations attached; market value is labelled as a forecast, not incremental revenue or Fruugo results. Google’s UCP documentation is context for future interoperability, not a conformance claim.

The supplied `Huugo_UX_and_Agentic_Shopping_Roundup.md` is an internal project briefing, not a completed live audit. The case study separates documented delivery, the reported early order signal and proposed future capabilities. It does not assert autonomous purchasing, deployed alerts, persistent personalisation or measured uplift.

The external Huugo CTA retains `https://huugo.fruugo.com/` from your previous portfolio. The briefing notes that the canonical launch address was unresolved during its review. Confirm this link before public release; edit `url` in `src/data/huugoProject.ts` if needed.

## Localisation evidence and delivery status

The third case study is available at `/work/fruugo-localisation`. Its project briefing is dated 9 October 2026, and its rollout wording reflects that snapshot. Confirm actual release completion before changing planned/test status to delivered.

The latest supplied registration total is 5,976, with 5,095 registered in China (85.3%). Country is a proxy for language need, not proof of native language or individual preference. The shopper percentages describe baseline reports; the 31–78% conversion comparison is observational, not a post-release causal uplift.

Matt’s audit account states just under 800 contextual screenshots **per supported language**, not 800 total or 800 defects. Playwright capture and AI analysis support scalable triage; native-language review and interactive accessibility testing remain necessary.

The case study explains Noto’s modular script support rather than claiming one Noto Sans file covers every script. It also distinguishes personal interface language from the company setting for enquiry replies. Internal Jira and Slack URLs are not included in the public-facing content. Review whether the remaining business figures are suitable for your public portfolio.

## Project imagery

The supplied materials contain no approved product screenshots or canonical Huugo artwork. Seven small SVGs in `public/images/` are clearly labelled journey and decision illustrations, not product screenshots, research evidence or newly invented Huugo artwork. They provide context while leaving the copy readable.

Replace these references with approved screenshots when available. Optimise screenshots first, place web-ready images in `public/images/`, and update the corresponding data fields. Public files are copied unchanged, so do not put high-resolution originals there. Images link to their full-size file in a new tab, with an accessible name explaining the destination.

## Peer-review excerpts

`src/data/peerReviews.ts` is the single editable list of genuine peer-review excerpts. It now contains short verbatim excerpts from the 2026 feedback supplied by Matt, attributed to Becky Lovell, Kieran Lynch and Ryan Duncan, plus a manager-review excerpt from Huw Evans.

Use a verbatim passage of about 25–45 words rather than automatically trimming a full review. Mark omissions with an ellipsis where appropriate and keep the intended meaning. Each entry needs a unique `id`, `quote`, reviewer `name` and `role`. Optional `context` describes the working relationship. Do not publish personal contact details.

Set `featured: true` for a homepage excerpt. At most four appear after Case studies, just before the contact section, giving collaboration evidence after the work has been presented. The first excerpt uses a larger typographic treatment on a tonal surface; Kieran, Ryan and Huw follow as open editorial rows with thematic labels and compact attribution. The Testimonials navigation item targets this homepage section.

Set `projectSlug` to the relevant existing slug to show a project-specific excerpt near the end of that case study, before its sources. A quote can be featured and project-linked, or only one of those. The same reusable `PeerReviews.vue` component supplies semantic blockquotes and attribution in both places.

Becky’s lead excerpt is from the supplied LinkedIn recommendation dated 22 July 2026. Her separate 2026 peer-review mentorship excerpt appears directly beneath her recommendation, with its own source label. No reviewer profile or outbound link is displayed. Kieran and Ryan are attributed as Fruugo colleagues because their job titles were not supplied. Huw is attributed as Matt’s manager, as identified by Matt; no additional job title is inferred from the PDF. None of these general endorsements are automatically associated with a project.

After editing the data, rebuild to include the quotes in static HTML. No new view, external service or dependency is required.

The supporting line “Customer insight, data and accessibility” sits below the name and role. On desktop the navigation grows into the remaining sidebar height, leaving the contact buttons at the bottom. On shorter screens the sidebar can scroll. The mobile header retains its menu and contact controls.

## Appearance and first render

A labelled Preferences button sits fixed at the top-right on desktop, separate from the sidebar contacts. Between 960px and 1279px it occupies the existing utility bar above the content. Below 960px it stays in normal header flow and scrolls away. It opens a native modal dialog with **Colour theme** (System preference, Light, Dark) and **Interface motion** (System preference, Reduced motion, Full motion). Native selects retain normal keyboard behaviour. Choices apply immediately without closing the dialog; Done, Close, Escape or a backdrop click dismiss it and restore focus. The page behind the modal is inert and its scroll position is retained.

Theme continues to use `portfolio-theme`. Motion uses the independent `portfolio-motion` local-storage key. Both default to System, resolve in the blocking head script before first paint, follow live device changes while System is selected and respond to updates from other tabs. Explicit choices override the device setting. When storage is blocked, choices still work in the current tab. Reduced motion disables non-essential CSS animation, transitions and smooth scrolling; the CSS device-preference fallback also works without JavaScript. No new animation is added.

Other native preferences exist: `prefers-contrast` could support a future tested contrast control, while `prefers-reduced-transparency` can support a transparency control in browsers that expose it. This update keeps only the two requested controls. Where reduced transparency is detected, dialog backdrops become opaque and their blur is removed automatically. Native forced-colours palettes are respected. `prefers-reduced-data` currently lacks usable browser support, so it is not presented as an available system setting.

`public/theme-init.js` is a small synchronous head script loaded on every generated page, before the stylesheet is applied. It sets `data-theme`, `data-theme-preference`, `color-scheme` and the browser theme colour before first paint. The Vue control hydrates with stable server markup, then reads the preference at mount. Do not defer this bootstrap or put it after the app bundle if you want to avoid a light flash for dark-mode visitors.

`src/assets/styles/tokens.css` holds light/dark semantic colour tokens. Cards, navigation, tags, evidence panels, buttons, focus and tooltips use these tokens. Changing theme is immediate, without a decorative transition. Without JavaScript, the CSS system-theme fallback still works; manual controls remain disabled. Images and SVG diagrams preserve their authored colours, rather than being inverted.

`npm run test:ui` checks the actual bootstrap under a simulated browser environment, storage/system transitions, palette contrast and passive router replacements. It does not replace browser, screen-reader or device testing.

## Navigation and accessibility

The case study keeps the sidebar identity and footer contact links. Email, LinkedIn and CV icons in the sidebar have accessible names, 44px targets and tooltips that appear on hover or keyboard focus and dismiss on Escape. The mobile navigation remains an in-flow disclosure.

Section links use home-route hashes, so they work from a case study. On the homepage, the hash is replaced to match the active item after scrolling settles, preserving query parameters and avoiding extra history entries. The passive replacement is tagged only for that navigation, so it does not move focus or trigger another scroll. Explicit section links and Back/Forward retain their normal behaviour. Case-study paths and image/source anchors are not rewritten by the homepage observer. Route changes move focus to the main content or the requested section. Browser Back/Forward uses saved scroll positions. The explicit “Back to case studies” link restores the remembered position when opened from the grid, and falls back to the section anchor after a direct visit or reload.

Cards become one column on narrow screens. Image dimensions reserve layout space, and reduced-motion preferences disable arrow transitions. Keep manual keyboard, screen-reader, zoom and real-device checks in your review.

## SEO

Every generated page includes a unique title and description, canonical URL, robots directive, Open Graph and Twitter text metadata, and JSON-LD. The homepage uses `ProfilePage` and `Person`; project pages use `CreativeWork`. Metadata also updates during client navigation. Sitemap URLs come from the same project list as the grid.

Social preview artwork is not included. Add an approved raster social image and image metadata if you want rich image previews.

A Lighthouse score has not been measured for this update. Static content and metadata address the underlying SEO requirements, but the final score also depends on the production origin, host behaviour and the audit environment. Run Lighthouse against the production build with the real public origin configured.

## Checks

```bash
npm run lint
npm run build
npm run test:static
npm run test:ui
```

The static check verifies generated routes, unique page titles, canonical URLs, metadata, readable case-study content, navigation links and image/asset files without launching a browser.

Optional local browser checks:

```bash
npx playwright install chromium
npm run test:e2e
```

For production hydration and the JavaScript-disabled static-page check on macOS/Linux:

```bash
npm run build
TEST_PREVIEW=1 npm run test:e2e
```

Stop an existing dev server on port 5173 before the preview tests, so the test runner launches the production server. On Windows PowerShell, use `$env:TEST_PREVIEW='1'; npm run test:e2e`.

Strict TypeScript, lint, changed-file formatting, builds, static HTML checks, theme logic, token contrast and passive router checks were run for this update. Browser tests and Lighthouse are provided for local validation and were not run here. Automated checks do not establish full accessibility conformance.

## Styling and portrait optimisation

The dimensions, spacing and interaction styling in `buttons.css` are retained; its colours now use semantic action tokens so both themes remain readable. Grid, case-study and sidebar-contact styles live in `src/assets/styles/projects.css`. Colours and widths remain in `tokens.css`, with system fonts and no external font requests.

Your supplied portrait is retained. Replace the single `profile` original in `src/assets/images/original/` if needed, using PNG, JPEG or WebP. `npm run images:optimise` runs automatically before development, type checks and builds; `npm run images:watch` can run in a second terminal. Sharp generates square 320px and 640px portraits and other WebP images, maintaining the existing pipeline.

`src/assets/images/dist/` contains generated source assets. The top-level `dist/` is the deployable website. Neither generated folder needs to be copied from this patch ZIP.

## Merchant onboarding and research methods

The fourth project is at `/work/fruugo-merchant-onboarding`. Its content is in `src/data/onboardingProject.ts`. It describes the shorter initial application, questions deferred to integration, collaboration across Product, Sales, Account Management, Technical Integration and Engineering, and data flowing into in-house applications, Monday.com and Salesforce.

The January update reports 24 total survey responses, average ratings of 4.5/5 for perceived effort and 4.3/5 for perceived time, and the fastest observed submission of 8 minutes 7 seconds. The earlier approximately 20-minute figure has an unspecified measurement basis. Do not describe the newer time as an average or infer a controlled percentage reduction. The year, survey scale anchors, question-level response counts and reporting window were not supplied.

The cover is a journey illustration, not a product screenshot. No application URL was provided, so this project has no external Visit CTA. The reusable project URL is optional; existing projects retain their links. Add a confirmed public application URL to this entry if appropriate.

The homepage headline is “Turning customer insights into clear, accessible products.” The research section also describes production A/B testing and Maze testing, with internal checkout participants stated explicitly. It does not assign either method to the onboarding project or invent a complete experiment result.

## Onboarding design evidence and responsive screenshots

The onboarding case study follows seven sections: problem and goal, role and collaboration, research, design decisions, validation, delivery/outcomes and learning. It contains two original application screenshots and three selected desktop Figma exports. The Figma images are design artefacts, not confirmation that every pictured detail shipped in the release described by the January feedback.

The five curated, cropped and redacted PNG originals live in `src/assets/images/original/onboarding/`. Never replace these with the unredacted uploads. Run `npm run images:optimise` after applying this patch. The same command also runs before development and builds. It generates 320, 640, 960 and up-to-1600px WebP variants for non-portrait assets; portrait generation stays at 320 and 640px. Small sources are not enlarged. Onboarding screenshots use quality 88 and effort 6 to retain interface text. Generated files are not supplied in the patch ZIP and are not committed as part of this update.

`src/data/onboardingImages.ts` imports the generated WebP assets. Vite hashes their URLs, and the same URLs appear in static HTML. ProjectFigure uses srcset, sizes, intrinsic dimensions and lazy loading for the screenshot figures. The full-size link opens a larger optimised WebP, never the original PNG. Other existing project images remain as supplied.

The reusable view supports optional decision blocks, each with its own text and image sequence. Existing project sections and single-image figures remain compatible. Before/after figures stack at full reading width so interface details are not squeezed into small columns. This implementation provides the structure for later project-by-project revisions; the other three stories have not been rewritten in this patch.

# portfolio-test

## Optimised project covers

All four cover PNGs in `public/images/` are now source inputs for `npm run images:optimise`. The command reads them directly, alongside the existing portrait and onboarding originals, and generates cover WebPs under `src/assets/images/dist/covers/`. You do not need to move or duplicate the original artwork.

Covers receive 320, 480, 640, 960 and up-to-1600px variants. A generated metadata file records actual dimensions so srcset descriptors and reserved layout space remain accurate. `src/data/projectCovers.ts` imports generated URLs, which Vite hashes for both static HTML and the hydrated application.

Homepage cards use their own responsive sizes and remain lazy-loaded. Each case study’s opening cover loads eagerly with high priority; subsequent figures are lazy-loaded at default priority. Full-size cover links open optimised WebP files. SVG diagrams remain vector assets. Original PNGs remain available in public/images as generation inputs, but the portfolio does not reference them in rendered images or full-size figure links.

After applying the patch, run `npm run images:optimise`, then build and redeploy. Development and production builds already run the optimiser automatically. No dependencies or environment-variable changes are needed. Generated cover images and metadata are excluded from this source patch.

## Case-study image viewer

Every ProjectFigure on a case-study page now opens a shared native dialog after JavaScript initialises, including covers, screenshots and SVG diagrams. Clicking, Enter or Space opens the viewer. Close, Escape or a pointer gesture beginning and ending outside the content dismisses it. Focus returns to the initiating image control. Navigation closes it and restores scrolling.

The viewer centres the image against a dark translucent backdrop with 0.4rem blur. It uses the existing optimised fullSrc URL (or src for diagrams), with no viewer image element before opening. Supporting page images remain lazy and the opening cover retains high priority. Without JavaScript or native modal-dialog support, ordinary full-size links remain available. No dependency or image-pipeline changes are required.

The close button has a visible label, a 44px minimum target and a high-contrast focus ring. The dialog is named, its caption remains available to assistive technology, and image-load errors offer a clear recovery message. There are no motion transitions. Playwright checks in tests/image-lightbox.spec.ts cover modal operation, dismissal, focus return, SVGs, screenshots, narrow viewports, both themes and navigation cleanup. Run these locally; browser tests and Lighthouse were not run for this patch.

## Case-study card imagery

All four cards share a 12:5 wallpaper header, with a separate screenshot inset 7% from either side and clipped at the lower edge. Its border and frame use the current theme tokens. Case-study page covers remain unchanged.

Replace `src/assets/images/original/cards/shared-background.png` with your resized wallpaper, retaining the filename. The supplied grey PNG is 960 × 400. Run `npm run images:optimise` to regenerate the WebP variants, then rebuild. Only generated WebP assets are served.

Accessible Trades uses the supplied interface screenshot in `src/assets/images/original/cards/accessible-trades.png`. Onboarding uses the existing document-upload screenshot. Huugo and localisation retain their current artwork until genuine interface screenshots are available. To replace any card image, add a PNG named after its project slug under `src/assets/images/original/cards/`, for example `huugo-from-fruugo.png`, `fruugo-localisation.png` or `fruugo-merchant-onboarding.png`. Run the optimiser and rebuild. The image helper discovers these assets automatically and reads their actual dimensions from generated metadata.

### Backgrounds per project

Each project’s `cover.cardBackground` controls its homepage card background independently. The component reads this URL from the project data, with no hardcoded shared image. Omitting the property gives a plain theme-aware background. Case-study covers and screenshot selection are unaffected.

The four project files currently import the existing shared background to preserve the default appearance. To use a different image for one project, add an original such as `src/assets/images/original/cards/huugo-background.png`, run `npm run images:optimise`, then change that project file’s background import:

```ts
import cardBackground from "@/assets/images/dist/cards/huugo-background-960.webp";

// Inside the existing cover object:
cardBackground,
```

Edit `src/data/huugoProject.ts`, `localisationProject.ts` or `onboardingProject.ts` for those projects, or `src/data/projects.ts` for Accessible Trades. Each import can point to its own generated WebP. Rebuild after changing the image or configuration.

## Accessible Trades case study

Accessible Trades now uses the same seven-section structure as merchant onboarding: problem and goal, role and collaboration, research and findings, design decisions, validation, delivery and outcomes, and learning. Three real screenshots illustrate search, company evidence and funding guidance. The homepage screenshot supplies the case-study cover. Directory/council coverage is described as England-wide, while the funding checker screen shows guidance routes for the four UK nations.

Keep the editable screenshots under `src/assets/images/original/accessible-trades/`. Run `npm run images:optimise` after replacing them. The page serves responsive WebPs with actual dimensions and no enlargement of smaller originals. Cropped inline previews use optional `previewAspectRatio` and `previewPosition`; full screenshots open in the existing native dialog. Long screenshots can scroll in the dialog, with the close control remaining available.

The supplied results capture is only 461px wide. Replace it with a higher-resolution export using the same filename when available; the helper reads generated dimensions automatically. The postcode council finder, saved/planning tools and management interface are described from Matt’s account, with no screenshots substituted for them.

Outcome figures reflect Matt’s October 2026 update: 240 company listings, current council coverage across England and API hosting under £10 per month at present scale. MND Association use and internal sharing are described separately from its pending February 2027 Helpful Links review. No feedback-led iteration, formal user-testing result, conversion gain, exact Lighthouse/axe score or guaranteed company suitability is claimed. The company evidence example is a council adaptation-framework award, rather than a grant awarded to the company.

## Printable CV

Open `/cv`, or choose **View my CV** from the portfolio. Select **Print / save as PDF**, then choose A4, 100% scale and disable browser headers and footers. The CV uses a fixed light print palette and the same font and visual style as the portfolio. Review the print preview after changing copy, as longer content can create additional pages.

Shared profile details live in `src/config/profile.ts`. The CV derives its introduction and recommendation directly from the portfolio data. Edit those sources once to update both views. CV-only employment dates, concise achievement bullets, older roles, education and capability labels live in `src/data/cv.ts`. Full case-study evidence is available through the portfolio link, rather than repeated without its context. Presentation and printing rules live in `src/views/CvView.vue` and `src/assets/styles/cv.css`.

Set `VITE_SITE_URL` to your published portfolio origin before a production build so the CV’s case-study links point to the correct site. Local previews use the existing public portfolio address as a fallback. The build prerenders `/cv` alongside the portfolio pages, so the CV remains readable without JavaScript; use the browser’s print menu if JavaScript is disabled.

## Shared social preview image

Every route includes a shared Open Graph and large Twitter/X preview image in its prerendered HTML and client-side metadata. The temporary asset is a solid warm off-white (`#FAFAF7`) PNG, 1200 × 630 pixels. Replace `public/images/portfolio-social-preview.png` with your final artwork at the same dimensions and PNG format, then rebuild and deploy. Update the image alternative text in `src/config/socialPreview.ts` to describe the final artwork. If you change the path, format or dimensions, update that configuration too.

Set `VITE_SITE_URL` to your actual production origin (currently `https://mdmoran2.netlify.app`) before building. The image URL is generated from this setting. Sharing services may cache old previews; after deployment, test the published link and allow for cache refresh. The placeholder is intentionally blank until replaced.

## Share image studio

The studio draws a 1200 × 630 canvas using the current CSS brand tokens and shared profile details. The preview and PNG/JPEG exports use the same renderer, with no new application dependency or image-generation server. Local file selections stay in the browser and are not uploaded. The studio is dynamically imported, so its controls and renderer are not loaded by normal portfolio visitors.

### Local use (default)

Run `npm run dev` and open `http://localhost:5173/_studio/share-image`. Use the actual port Vite reports. Vite’s default loopback host keeps this on your computer; do not expose the development server publicly. Production builds exclude the studio route and chunk unless explicitly enabled.

Edit `src/tools/share-image/config.ts` to change the default headline, images, card positions, angles and crop focus. Name and role come from `src/config/profile.ts`; image choices also include the portfolio’s project covers. Colours and fonts are read from the shared CSS tokens. The controls let you adjust copy, choose project images or use temporary local PNG/JPEG/WebP files. Reset restores the code defaults. Theme changes use the portfolio’s shared theme preference.

Choose **Portfolio** for the existing three-image layout or **Case study** for a single featured image with the project title. Selecting a case study loads its copy and cover from the shared project data. Edit `studioCaseStudies` and `caseStudyLayout` in `src/tools/share-image/config.ts` for persistent copy, crop and layout defaults. All text, image selection, local upload and crop controls remain available in either template. Switching template/project restores its code defaults; unsaved UI edits are session-only.

The **LinkedIn header** template changes the preview and export to **1584 × 396**, with the left 36% clear for the profile photograph. Its two-line headline and supporting copy are defined in `linkedinDefaults` in `src/tools/share-image/config.ts`. `studioTemplates` owns dimensions and export filenames. The header omits name, role and project-image controls, and uses the same theme, text editing, reset and PNG/JPEG export controls. With no explicit line break, the renderer balances the headline over two lines; with one break, it respects your chosen split. Oversized copy produces a clear error instead of a clipped download. Upload the exported header directly to LinkedIn; no deployment is required. Colours, font and component outlines use the shared portfolio tokens, with light/dark previews available.

Each case study has its own public 1200 × 630 PNG in `public/images/social/`. Starter images are included. The studio displays the destination filename and exports using the selected case-study slug. For the portfolio template, replace `public/images/portfolio-social-preview.png`.

`src/config/socialPreview.ts` is the single configuration for metadata: `pageSocialPreviews` maps URL paths to image path, alt text, MIME type and dimensions. Add `/cv` or any future route here to override the default portfolio image. Trailing slashes are normalised. Set alt text to describe the exported artwork. Both prerendered HTML and client-side navigation use these settings for Open Graph and Twitter cards; project descriptions continue to come from `seoDescription` in project data.

Download the PNG, copy it to the displayed `public/` location and rebuild/deploy. Downloads do not modify the site or metadata automatically. For JPEG or a new filename, update the path and MIME type in the map. Social platforms may cache old previews; a new asset filename can help when replacing an already shared image. Use locally imported images in the configuration; arbitrary third-party images can prevent canvas export because of browser CORS rules.

The case-study template remains inside the studio's lazy chunk. It adds no canvas tool code or dependencies to public pages. Public share images are metadata resources, not extra images fetched by the portfolio UI.

### Optional password-protected Netlify deployment

The URL is unlisted, but an unlisted URL and `noindex` are not authentication. To make the studio available on your hosted Netlify site:

1. Set the **build** variable `VITE_ENABLE_SHARE_STUDIO=true`.
2. Set **Functions/runtime** variables `SHARE_STUDIO_USER` and `SHARE_STUDIO_PASSWORD` in Netlify’s environment settings. Choose a long unique password of at least 16 characters. Keep both out of source control and never prefix these credentials with `VITE_`.
3. Deploy the project **from source**, including `netlify/edge-functions/share-studio-auth.js`. A static drag-and-drop upload of `dist` does not deploy the access guard and must not be used with the studio enabled.
4. Open `https://mdmoran2.netlify.app/_studio/share-image` and sign in with the browser’s authentication prompt. Check that a private/incognito window gets an authentication challenge, and that the studio JS/CSS assets are protected too.

The Netlify edge guard protects the studio HTML and its lazy JS/CSS chunk, rejects requests when credentials are missing, and prevents response caching. It does not run on public portfolio pages. The studio is omitted from navigation, the sitemap and structured data and carries `noindex, nofollow, noarchive` metadata and headers. Anyone who has the credentials can access it; keep them private. The local Vite/preview servers do not emulate Netlify authentication. Disable the build flag to remove the tool from future production builds.

# Case-study reading time and progress

Each case study displays an approximate reading time calculated from its current
visible article copy at **238 words per minute**, rounded up to a whole minute.
This uses the English non-fiction silent-reading estimate in Marc Brysbaert’s
2019 review and meta-analysis of 190 studies (18,573 participants):
[published research summary](https://biblio.ugent.be/publication/8647789),
[DOI](https://doi.org/10.1016/j.jml.2019.104047).

`src/utils/caseStudyReading.ts` counts headings, paragraphs, evidence cards,
steps, figure labels and captions, project recommendations and source descriptions.
It excludes navigation, URLs, hidden image descriptions and metadata. The estimate
updates automatically when these content objects change and is available in the
prerendered HTML. It estimates text reading, rather than guaranteeing a completion
time; inspecting screenshots and individual reading speeds vary. No invented
image-viewing allowance is attributed to the research.

The fixed progress indicator tracks the current scroll position from the article
start to the end of its readable content, before the closing navigation and footer.
It uses a 56px ring at viewport widths of 1440px and above, where the layout leaves
room beside the article. Smaller screens use a compact fixed horizontal strip at the bottom of the
viewport. Extra space below the content and device safe-area padding keep final
links clear of the strip and phone home indicators.
The mobile header retains its existing behaviour.

Progress can decrease when scrolling upwards. Layout changes, image loading,
font loading, resizing and restored scroll positions trigger recalculation. The
indicator has an accessible name and numeric value without live announcements
or extra dependencies. It appears only on valid case-study pages and
is omitted from print output.

After building, run `node scripts/verify-case-reading.mjs` to check the estimates,
geometry and route isolation alongside the existing static and UI checks.

Each time progress moves from below 100% to 100%, a pastel confetti burst plays from the
desktop ring or from the centre behind the smaller-screen progress strip. Only
20 decorative pieces rise, tumble and fall on varied arcs over roughly 2.3–3
seconds, then are removed after 3.4 seconds. The native Web Animations API animates
transform and opacity, with no library, canvas or image assets. A separate pastel
palette keeps the paper colours independent of the interface theme. It follows
the existing resolved motion preference, including the device setting when
System is selected. Reduced motion skips the burst; changing to reduced motion
cancels an active burst immediately. Remaining at 100% does not repeatedly trigger bursts. If motion
is off at completion, enabling it later does not replay the burst; scrolling
back below 100% rearms it. Rapid repeated completion restarts the animation
without stacking particles or timers. Changing case studies
resets the burst. The particles are hidden from assistive technology and do not
intercept pointer events. The verification script checks repeat completion,
motion suppression and reset alongside reading estimates.

## Mobile previews alongside case-study covers

Project cards retain the original 12:5 media area and desktop image size and
position. A smaller portrait phone overlays the right side. Case-study covers
also remain full width, with the phone overlaid on the right and its label and
caption below the main image. Placeholders
are explicitly labelled and do not represent delivered mobile interfaces.

To replace a placeholder, add a real portrait PNG, JPEG or WebP screenshot to
`src/assets/images/original/mobile/` using one of these filename stems:

- `fruugo-localisation`
- `fruugo-merchant-onboarding`
- `huugo-from-fruugo`
- `accessible-trades`

For example, use `src/assets/images/original/mobile/accessible-trades.png`.
Run `npm run images:optimise` while developing, or run `npm run build` (which
optimises images automatically). Rebuild and redeploy: the preview automatically
uses the optimised WebP variants and replaces its placeholder label. Keep only
one original per filename stem. Edit the image-specific alt text and caption in
`src/data/projectMobilePreviews.ts` to describe what the screenshot demonstrates.

Capture the actual responsive interface without a phone frame, ideally around
390px wide. The component supplies the frame. Its viewport crops long screenshots
from the top; on the case-study page, clicking a real screenshot opens the full
image using the existing lightbox or a new-tab fallback. Placeholders do not open
an empty preview. Card images remain decorative, while the case-study images have
alt text and captions. Reading estimates include the new labels and captions.

Choose a screenshot that shows a meaningful mobile decision, such as navigation,
form layout, translated text wrapping or the chat composer. A frame alone is a
presentation aid; the actual screenshot and accompanying explanation provide
evidence of responsive design.

### Included mobile assets

Accessible Trades and merchant onboarding use the supplied iPhone-viewport
screenshots. Localisation and Huugo use generated portrait illustrations based
on the existing language-tile artwork and Huugo master character, respectively.
Their captions explicitly describe artwork, not a delivered mobile interface.
All four assets now open in the case-study image viewer. Original PNGs are in
`src/assets/images/original/mobile/`; responsive WebP variants are included.

Update the labels, alt text and captions in the `descriptions` map in
`src/data/projectMobilePreviews.ts` when replacing an illustration with a real
interface capture. The original mobile filenames stay the same.

Onboarding’s case-study header now uses `projectHeaderImage()` from
`src/data/projectCardImages.ts`, which takes the same selected screenshot as the
homepage card. Its header crop keeps the existing wide composition, while the
image viewer opens the full screenshot.
